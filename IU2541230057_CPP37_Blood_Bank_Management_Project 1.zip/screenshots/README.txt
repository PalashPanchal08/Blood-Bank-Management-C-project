Place genuine screenshots of your own program execution here before final submission.
