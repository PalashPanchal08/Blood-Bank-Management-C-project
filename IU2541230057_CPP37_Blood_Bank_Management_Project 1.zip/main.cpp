#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <ctime>
#include <limits>
#include <stdexcept>
#include <algorithm>

using namespace std;

// Base class: demonstrates inheritance and runtime polymorphism.
class Record {
protected:
    int id;
public:
    Record(int value = 0) : id(value) {}
    virtual ~Record() {}
    int getId() const { return id; }
    virtual string type() const = 0;
    virtual void display() const = 0;
};

class Donor : public Record {
private:
    string name, bloodGroup;
    int age;
public:
    Donor() : Record(0), name(""), bloodGroup(""), age(0) {}
    Donor(int i, string n, int a, string bg) : Record(i), name(n), bloodGroup(bg), age(a) {}
    string getName() const { return name; }
    string getBloodGroup() const { return bloodGroup; }
    int getAge() const { return age; }
    bool eligible() const { return age >= 18 && age <= 65; }
    string type() const override { return "Donor"; }
    void display() const override {
        cout << left << setw(8) << id << setw(24) << name << setw(8) << age
             << setw(12) << bloodGroup << (eligible() ? "Eligible" : "Not eligible") << '\n';
    }
    string serialize() const { return to_string(id) + "|" + name + "|" + to_string(age) + "|" + bloodGroup; }
};

class BloodUnit : public Record {
private:
    int donorId, quantity;
    string bloodGroup, expiry;
public:
    BloodUnit() : Record(0), donorId(0), quantity(0), bloodGroup(""), expiry("") {}
    BloodUnit(int i, int d, string bg, int q, string ex)
        : Record(i), donorId(d), quantity(q), bloodGroup(bg), expiry(ex) {}
    int getDonorId() const { return donorId; }
    int getQuantity() const { return quantity; }
    string getBloodGroup() const { return bloodGroup; }
    string getExpiry() const { return expiry; }
    void setQuantity(int q) { quantity = q; }
    bool isExpired() const {
        // Expiry is stored as YYYY-MM-DD; ISO date strings sort chronologically.
        return expiry.size() == 10 && expiry < currentDate();
    }
    static string currentDate() {
        time_t now = time(nullptr);
        tm *lt = localtime(&now);
        char buf[11];
        strftime(buf, sizeof(buf), "%Y-%m-%d", lt);
        return string(buf);
    }
    string type() const override { return "BloodUnit"; }
    void display() const override {
        cout << left << setw(8) << id << setw(10) << donorId << setw(12) << bloodGroup
             << setw(12) << quantity << setw(14) << expiry << (isExpired() ? "Expired" : "Valid") << '\n';
    }
    string serialize() const { return to_string(id) + "|" + to_string(donorId) + "|" + bloodGroup + "|" + to_string(quantity) + "|" + expiry; }
};

class Patient : public Record {
private:
    string name, bloodGroup;
    int unitsRequired;
public:
    Patient() : Record(0), name(""), bloodGroup(""), unitsRequired(0) {}
    Patient(int i, string n, string bg, int u) : Record(i), name(n), bloodGroup(bg), unitsRequired(u) {}
    string getName() const { return name; }
    string getBloodGroup() const { return bloodGroup; }
    int getUnitsRequired() const { return unitsRequired; }
    string type() const override { return "Patient"; }
    void display() const override {
        cout << left << setw(8) << id << setw(24) << name << setw(12) << bloodGroup << unitsRequired << '\n';
    }
    string serialize() const { return to_string(id) + "|" + name + "|" + bloodGroup + "|" + to_string(unitsRequired); }
};

class Request : public Record {
private:
    int patientId, quantity;
    string bloodGroup, status;
public:
    Request() : Record(0), patientId(0), quantity(0), bloodGroup(""), status("Pending") {}
    Request(int i, int p, string bg, int q, string st = "Pending")
        : Record(i), patientId(p), quantity(q), bloodGroup(bg), status(st) {}
    int getPatientId() const { return patientId; }
    int getQuantity() const { return quantity; }
    string getBloodGroup() const { return bloodGroup; }
    string getStatus() const { return status; }
    void setStatus(const string& s) { status = s; }
    string type() const override { return "Request"; }
    void display() const override {
        cout << left << setw(8) << id << setw(12) << patientId << setw(12) << bloodGroup
             << setw(10) << quantity << status << '\n';
    }
    string serialize() const { return to_string(id) + "|" + to_string(patientId) + "|" + bloodGroup + "|" + to_string(quantity) + "|" + status; }
};

class FileManager {
public:
    template <typename T>
    static void saveRecords(const string& file, T* arr, int count) {
        ofstream out(file.c_str());
        if (!out) throw runtime_error("Unable to open data file for writing: " + file);
        for (int i = 0; i < count; ++i) out << arr[i].serialize() << '\n';
    }
    template <typename T, typename Parser>
    static void loadRecords(const string& file, T*& arr, int& count, int& capacity, Parser parser) {
        ifstream in(file.c_str());
        if (!in) return; // First run: no data file exists yet.
        string line;
        while (getline(in, line)) {
            if (line.empty()) continue;
            try {
                T item = parser(line);
                if (count == capacity) {
                    int next = capacity * 2;
                    T* temp = new T[next];
                    for (int i = 0; i < count; ++i) temp[i] = arr[i];
                    delete[] arr;
                    arr = temp;
                    capacity = next;
                }
                arr[count++] = item;
            } catch (...) {
                cerr << "Skipped malformed line in " << file << '\n';
            }
        }
    }
};

class BloodBank {
private:
    Donor* donors;
    BloodUnit* units;
    Patient* patients;
    Request* requests;
    int donorCount, unitCount, patientCount, requestCount;
    int donorCap, unitCap, patientCap, requestCap;
    int nextDonorId, nextUnitId, nextPatientId, nextRequestId;
    string dataDir;

    template <typename T>
    void grow(T*& arr, int& cap) {
        int newCap = cap * 2;
        T* tmp = new T[newCap];
        for (int i = 0; i < cap; ++i) tmp[i] = arr[i];
        delete[] arr;
        arr = tmp;
        cap = newCap;
    }
    template <typename T>
    void ensureRoom(T*& arr, int count, int& cap) {
        if (count >= cap) grow(arr, cap);
    }
    static string field(stringstream& ss) {
        string value;
        if (!getline(ss, value, '|')) throw runtime_error("Malformed record");
        return value;
    }
    static int toInt(const string& s) {
        size_t used = 0;
        int v = stoi(s, &used);
        if (used != s.size()) throw runtime_error("Invalid integer");
        return v;
    }
    static string clean(const string& s) {
        if (s.find('|') != string::npos || s.find('\n') != string::npos || s.find('\r') != string::npos)
            throw invalid_argument("Text fields cannot contain | or line breaks.");
        return s;
    }
    static bool validBloodGroup(const string& bg) {
        const string groups[] = {"A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"};
        for (const string& g : groups) if (bg == g) return true;
        return false;
    }
    int findDonorIndex(int id) const { for (int i=0;i<donorCount;++i) if (donors[i].getId()==id) return i; return -1; }
    int findUnitIndex(int id) const { for (int i=0;i<unitCount;++i) if (units[i].getId()==id) return i; return -1; }
    int findPatientIndex(int id) const { for (int i=0;i<patientCount;++i) if (patients[i].getId()==id) return i; return -1; }
    int findRequestIndex(int id) const { for (int i=0;i<requestCount;++i) if (requests[i].getId()==id) return i; return -1; }
    template <typename T>
    static void eraseAt(T* arr, int& count, int idx) {
        for (int i=idx;i<count-1;++i) arr[i]=arr[i+1];
        --count;
    }
    void printMenu() const {
        cout << "\n========== BLOOD BANK MANAGEMENT ==========\n"
             << "1. Add Record\n2. Display Records\n3. Search Record\n4. Update Record\n"
             << "5. Delete Record\n6. Main Transaction / Process\n7. Report\n"
             << "8. Save / Load\n9. Exit\nChoose: ";
    }
    int readInt(const string& prompt, int minValue, int maxValue) const {
        int v;
        while (true) {
            cout << prompt;
            if (cin >> v && v >= minValue && v <= maxValue) {
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                return v;
            }
            cout << "Invalid input. Enter a number from " << minValue << " to " << maxValue << ".\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }
    string readText(const string& prompt) const {
        string s;
        while (true) {
            cout << prompt;
            getline(cin, s);
            try {
                s = clean(s);
                if (s.empty()) throw invalid_argument("Value cannot be empty.");
                return s;
            } catch (const exception& e) { cout << e.what() << '\n'; }
        }
    }
    string readBG() const {
        while (true) {
            string bg = readText("Blood group (A+, A-, B+, B-, AB+, AB-, O+, O-): ");
            if (validBloodGroup(bg)) return bg;
            cout << "Invalid blood group.\n";
        }
    }
    static Donor parseDonor(const string& line) {
        stringstream ss(line); int id=toInt(field(ss)); string n=field(ss); int age=toInt(field(ss)); string bg=field(ss);
        return Donor(id,n,age,bg);
    }
    static BloodUnit parseUnit(const string& line) {
        stringstream ss(line); int id=toInt(field(ss)); int d=toInt(field(ss)); string bg=field(ss); int q=toInt(field(ss)); string ex=field(ss);
        return BloodUnit(id,d,bg,q,ex);
    }
    static Patient parsePatient(const string& line) {
        stringstream ss(line); int id=toInt(field(ss)); string n=field(ss); string bg=field(ss); int u=toInt(field(ss));
        return Patient(id,n,bg,u);
    }
    static Request parseRequest(const string& line) {
        stringstream ss(line); int id=toInt(field(ss)); int p=toInt(field(ss)); string bg=field(ss); int q=toInt(field(ss)); string st=field(ss);
        return Request(id,p,bg,q,st);
    }
    void addDonor() {
        string name = readText("Donor name: ");
        int age = readInt("Age (1-120): ",1,120);
        string bg = readBG();
        ensureRoom(donors, donorCount, donorCap);
        donors[donorCount++] = Donor(nextDonorId++,name,age,bg);
        cout << "Donor added successfully. Donor ID: " << nextDonorId-1 << '\n';
    }
    void addPatient() {
        string name = readText("Patient name: ");
        string bg = readBG();
        int qty = readInt("Units required (1-100): ",1,100);
        ensureRoom(patients, patientCount, patientCap);
        patients[patientCount++] = Patient(nextPatientId++,name,bg,qty);
        cout << "Patient added successfully. Patient ID: " << nextPatientId-1 << '\n';
    }
    void collectBlood() {
        int did = readInt("Donor ID: ",1,1000000000);
        int di = findDonorIndex(did);
        if (di < 0) { cout << "Donor not found.\n"; return; }
        if (!donors[di].eligible()) { cout << "Donor is not eligible (age must be 18-65).\n"; return; }
        int qty = readInt("Quantity in units (1-20): ",1,20);
        string bg = donors[di].getBloodGroup();
        string expiry;
        while (true) {
            expiry = readText("Expiry date (YYYY-MM-DD): ");
            if (expiry.size()==10 && expiry[4]=='-' && expiry[7]=='-' &&
                all_of(expiry.begin(),expiry.end(),[](char c){return isdigit(static_cast<unsigned char>(c)) || c=='-';}) &&
                expiry >= BloodUnit::currentDate()) break;
            cout << "Enter a valid ISO date that is today or later.\n";
        }
        ensureRoom(units,unitCount,unitCap);
        units[unitCount++] = BloodUnit(nextUnitId++,did,bg,qty,expiry);
        cout << "Blood collected. Unit ID: " << nextUnitId-1 << '\n';
    }
    void createRequest() {
        int pid = readInt("Patient ID: ",1,1000000000);
        int pi = findPatientIndex(pid);
        if (pi < 0) { cout << "Patient not found.\n"; return; }
        int qty = readInt("Units requested (1-100): ",1,100);
        ensureRoom(requests,requestCount,requestCap);
        requests[requestCount++] = Request(nextRequestId++,pid,patients[pi].getBloodGroup(),qty);
        cout << "Request created. Request ID: " << nextRequestId-1 << '\n';
    }
    void issueBlood() {
        int rid = readInt("Request ID to fulfill: ",1,1000000000);
        int ri = findRequestIndex(rid);
        if (ri < 0) { cout << "Request not found.\n"; return; }
        if (requests[ri].getStatus() != "Pending") { cout << "Request is not pending.\n"; return; }
        int need = requests[ri].getQuantity();
        int available = 0;
        for (int i=0;i<unitCount;++i)
            if (!units[i].isExpired() && units[i].getBloodGroup()==requests[ri].getBloodGroup()) available += units[i].getQuantity();
        if (available < need) {
            cout << "Insufficient compatible unexpired stock. Available units: " << available << '\n';
            return;
        }
        // Check first, then deduct, so a failed request never partially changes stock.
        int remaining = need;
        for (int i=0;i<unitCount && remaining>0;++i) {
            if (!units[i].isExpired() && units[i].getBloodGroup()==requests[ri].getBloodGroup()) {
                int take = min(remaining, units[i].getQuantity());
                units[i].setQuantity(units[i].getQuantity()-take);
                remaining -= take;
            }
        }
        requests[ri].setStatus("Fulfilled");
        cout << "Blood issued successfully. Units issued: " << need << '\n';
    }
    void displayAll() const {
        cout << "\n--- Donors ---\nID      Name                    Age     Blood Group Status\n";
        if (!donorCount) cout << "No donor records.\n";
        for (int i=0;i<donorCount;++i) donors[i].display();
        cout << "\n--- Blood Units ---\nID      Donor ID  Blood Group Quantity    Expiry        Status\n";
        if (!unitCount) cout << "No blood units.\n";
        for (int i=0;i<unitCount;++i) units[i].display();
        cout << "\n--- Patients ---\nID      Name                    Blood Group Units Required\n";
        if (!patientCount) cout << "No patient records.\n";
        for (int i=0;i<patientCount;++i) patients[i].display();
        cout << "\n--- Requests ---\nID      Patient ID  Blood Group Quantity  Status\n";
        if (!requestCount) cout << "No requests.\n";
        for (int i=0;i<requestCount;++i) requests[i].display();
    }
    void searchRecord() const {
        cout << "Search: 1 Donor  2 Blood Unit  3 Patient  4 Request\n";
        int type = readInt("Type: ",1,4);
        int id = readInt("Record ID: ",1,1000000000);
        int idx = -1;
        if (type==1) idx=findDonorIndex(id);
        if (type==2) idx=findUnitIndex(id);
        if (type==3) idx=findPatientIndex(id);
        if (type==4) idx=findRequestIndex(id);
        if (idx<0) { cout << "Record not found.\n"; return; }
        if (type==1) donors[idx].display();
        if (type==2) units[idx].display();
        if (type==3) patients[idx].display();
        if (type==4) requests[idx].display();
    }
    void updateRecord() {
        cout << "Update: 1 Donor  2 Patient\n";
        int type = readInt("Type: ",1,2);
        int id = readInt("Record ID: ",1,1000000000);
        if (type==1) {
            int i=findDonorIndex(id); if (i<0) { cout<<"Donor not found.\n"; return; }
            string n=readText("New name: "); int age=readInt("New age (1-120): ",1,120); string bg=readBG();
            donors[i]=Donor(id,n,age,bg); cout<<"Donor updated.\n";
        } else {
            int i=findPatientIndex(id); if (i<0) { cout<<"Patient not found.\n"; return; }
            string n=readText("New name: "); string bg=readBG(); int q=readInt("New units required (1-100): ",1,100);
            patients[i]=Patient(id,n,bg,q); cout<<"Patient updated.\n";
        }
    }
    void deleteRecord() {
        cout << "Delete: 1 Donor  2 Blood Unit  3 Patient  4 Request\n";
        int type=readInt("Type: ",1,4); int id=readInt("Record ID: ",1,1000000000);
        if(type==1) {
            int i=findDonorIndex(id); if(i<0){cout<<"Donor not found.\n";return;}
            for(int j=0;j<unitCount;++j) if(units[j].getDonorId()==id){cout<<"Cannot delete donor with blood units. Delete units first.\n";return;}
            eraseAt(donors,donorCount,i); cout<<"Donor deleted.\n";
        } else if(type==2) {
            int i=findUnitIndex(id); if(i<0){cout<<"Blood unit not found.\n";return;}
            eraseAt(units,unitCount,i); cout<<"Blood unit deleted.\n";
        } else if(type==3) {
            int i=findPatientIndex(id); if(i<0){cout<<"Patient not found.\n";return;}
            for(int j=0;j<requestCount;++j) if(requests[j].getPatientId()==id){cout<<"Cannot delete patient with requests. Delete requests first.\n";return;}
            eraseAt(patients,patientCount,i); cout<<"Patient deleted.\n";
        } else {
            int i=findRequestIndex(id); if(i<0){cout<<"Request not found.\n";return;}
            eraseAt(requests,requestCount,i); cout<<"Request deleted.\n";
        }
    }
    void report() const {
        int stock=0, expired=0, pending=0, fulfilled=0;
        for(int i=0;i<unitCount;++i){ if(units[i].isExpired()) ++expired; else stock+=units[i].getQuantity(); }
        for(int i=0;i<requestCount;++i){ if(requests[i].getStatus()=="Pending") ++pending; else if(requests[i].getStatus()=="Fulfilled") ++fulfilled; }
        cout << "\n========== BLOOD BANK REPORT ==========\n"
             << "Total donors: " << donorCount << "\nTotal patients: " << patientCount
             << "\nBlood unit records: " << unitCount << "\nAvailable unexpired units: " << stock
             << "\nExpired unit records: " << expired << "\nTotal requests: " << requestCount
             << "\nPending requests: " << pending << "\nFulfilled requests: " << fulfilled << '\n';
    }
    void saveAll() const {
        FileManager::saveRecords(dataDir+"/donors.txt",donors,donorCount);
        FileManager::saveRecords(dataDir+"/blood_units.txt",units,unitCount);
        FileManager::saveRecords(dataDir+"/patients.txt",patients,patientCount);
        FileManager::saveRecords(dataDir+"/requests.txt",requests,requestCount);
        ofstream meta((dataDir+"/ids.txt").c_str());
        if(!meta) throw runtime_error("Unable to save ID counters.");
        meta << nextDonorId << '\n' << nextUnitId << '\n' << nextPatientId << '\n' << nextRequestId << '\n';
        cout << "All records saved.\n";
    }
    void loadAll() {
        FileManager::loadRecords(dataDir+"/donors.txt",donors,donorCount,donorCap,parseDonor);
        FileManager::loadRecords(dataDir+"/blood_units.txt",units,unitCount,unitCap,parseUnit);
        FileManager::loadRecords(dataDir+"/patients.txt",patients,patientCount,patientCap,parsePatient);
        FileManager::loadRecords(dataDir+"/requests.txt",requests,requestCount,requestCap,parseRequest);
        ifstream meta((dataDir+"/ids.txt").c_str());
        if(meta) {
            int a,b,c,d;
            if(meta>>a>>b>>c>>d) { nextDonorId=a; nextUnitId=b; nextPatientId=c; nextRequestId=d; return; }
        }
        for(int i=0;i<donorCount;++i) nextDonorId=max(nextDonorId,donors[i].getId()+1);
        for(int i=0;i<unitCount;++i) nextUnitId=max(nextUnitId,units[i].getId()+1);
        for(int i=0;i<patientCount;++i) nextPatientId=max(nextPatientId,patients[i].getId()+1);
        for(int i=0;i<requestCount;++i) nextRequestId=max(nextRequestId,requests[i].getId()+1);
    }
public:
    explicit BloodBank(string folder="Data")
        : donors(new Donor[10]), units(new BloodUnit[10]), patients(new Patient[10]), requests(new Request[10]),
          donorCount(0),unitCount(0),patientCount(0),requestCount(0),
          donorCap(10),unitCap(10),patientCap(10),requestCap(10),
          nextDonorId(1),nextUnitId(1),nextPatientId(1),nextRequestId(1),dataDir(folder) {
        loadAll();
    }
    ~BloodBank() {
        try { saveAll(); } catch(const exception& e) { cerr << "Warning: " << e.what() << '\n'; }
        delete[] donors; delete[] units; delete[] patients; delete[] requests;
    }
    void run() {
        bool running=true;
        while(running) {
            try {
                printMenu();
                int choice=readInt("",1,9);
                switch(choice) {
                    case 1: {
                        cout<<"Add: 1 Donor  2 Patient  3 Collect Blood  4 Create Request\n";
                        int t=readInt("Type: ",1,4);
                        if(t==1)addDonor(); else if(t==2)addPatient(); else if(t==3)collectBlood(); else createRequest();
                        break;
                    }
                    case 2: displayAll(); break;
                    case 3: searchRecord(); break;
                    case 4: updateRecord(); break;
                    case 5: deleteRecord(); break;
                    case 6:
                        cout<<"Transaction: 1 Collect Blood  2 Create Patient Request  3 Issue Blood\n";
                        { int t=readInt("Type: ",1,3); if(t==1)collectBlood(); else if(t==2)createRequest(); else issueBlood(); }
                        break;
                    case 7: report(); break;
                    case 8:
                        cout<<"1 Save now  2 Reload from files\n";
                        { int t=readInt("Choose: ",1,2); if(t==1)saveAll(); else {
                            // Reload only after clearing current in-memory records.
                            donorCount=unitCount=patientCount=requestCount=0;
                            nextDonorId=nextUnitId=nextPatientId=nextRequestId=1;
                            loadAll(); cout<<"Data loaded from files.\n";
                        }}
                        break;
                    case 9: saveAll(); running=false; cout<<"Goodbye.\n"; break;
                }
            } catch(const exception& e) { cout<<"Operation failed: "<<e.what()<<'\n'; }
        }
    }
};

int main() {
    try {
        BloodBank system("Data");
        system.run();
    } catch(const exception& e) {
        cerr << "Fatal error: " << e.what() << '\n';
        return 1;
    }
    return 0;
}
