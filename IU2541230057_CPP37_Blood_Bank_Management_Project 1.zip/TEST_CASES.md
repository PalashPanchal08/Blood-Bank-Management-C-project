# Test Cases — Blood Bank Management

Run each test on your own machine. This table lists expected behaviour; replace the actual-result field with what you observe and mark Pass/Fail only after execution.

| Test ID | Operation | Input / Setup | Expected Output | Actual Result / Status |
|---|---|---|---|---|
|T01|Add donor|Name=Riya, age=25, blood group=O+|Donor created with next donor ID|Verify on local run|
|T02|Add patient|Name=Patient A, blood group=A+, units=2|Patient created with next patient ID|Verify on local run|
|T03|Invalid blood group|Enter X+|Validation rejects it and asks again|Verify on local run|
|T04|Donor eligibility|Donor age=17; collect blood|Collection blocked as donor is ineligible|Verify on local run|
|T05|Collect blood|Eligible O+ donor; quantity=3; future expiry|Blood unit record created|Verify on local run|
|T06|Create request|Existing patient; quantity=1|Request created with Pending status|Verify on local run|
|T07|Fulfill available request|Matching unexpired stock >= requested quantity|Stock decreases and request becomes Fulfilled|Verify on local run|
|T08|Insufficient stock|Request more matching units than available|Request remains Pending; stock unchanged|Verify on local run|
|T09|Expired stock|Matching unit expiry before current date|Expired stock excluded from available inventory|Verify on local run|
|T10|Search existing donor|Choose donor and valid ID|Matching donor is displayed|Verify on local run|
|T11|Search missing record|Choose any type and unused ID|Record not found message|Verify on local run|
|T12|Update patient|Existing patient ID; enter new details|Patient details are updated|Verify on local run|
|T13|Delete request|Existing request ID|Request removed from in-memory records|Verify on local run|
|T14|Persistence|Save, close, reopen application|Previously saved records load again|Verify on local run|
|T15|Invalid menu input|Enter letters or number outside 1-9|Input is rejected and prompt repeats|Verify on local run|
