@echo off
g++ -std=c++11 -Wall -Wextra -pedantic main.cpp -o BloodBank.exe
if errorlevel 1 pause
